package com.ms.cloud.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.ms.cloud.client.OrderServiceFeignClient;
import com.ms.cloud.model.Customer;
import com.ms.cloud.model.OrderModel;

@RestController

public class CustomerController {
	@Autowired
	OrderServiceFeignClient client;
	
	@GetMapping(path = "/getcustomer/{name}/{id}")
	public Customer getCustomer(@PathVariable String name, @PathVariable String id) {
		OrderModel model = client.getOrder(id, name);
		return new Customer(name, id, model.getPort(), model.getOrderId());
	}
	
}


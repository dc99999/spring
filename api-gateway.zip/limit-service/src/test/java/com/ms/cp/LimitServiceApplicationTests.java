package com.ms.cp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LimitServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
